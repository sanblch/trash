.. spelling::

    wyrm

.. index::
  single: unsorted ; wyrm
  single: pybind11 ; wyrm

.. _pkg.wyrm:

wyrm
====

-  `Official <https://gitlab.obspm.fr/greenflash/wyrm>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/wyrm/CMakeLists.txt>`__
-  Added by `Arnaud Sevin <https://github.com/a-sevin>`__ (`pr-1790 <https://github.com/ruslo/hunter/pull/1790>`__)

.. literalinclude:: /../examples/wyrm/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
