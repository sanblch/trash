#import <Foundation/Foundation.h>

int main() {
  NSLog(@"Hello");
}
