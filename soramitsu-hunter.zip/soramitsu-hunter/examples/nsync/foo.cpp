#include "nsync/nsync.h"

int main() {
}
