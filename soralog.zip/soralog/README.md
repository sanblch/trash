# soralog
Fast&amp;flex logger for Soramitsu LABS
