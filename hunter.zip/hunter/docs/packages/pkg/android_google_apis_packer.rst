.. spelling::

    android
    google
    apis
    packer

.. index:: android_sdk_component ; android_google_apis_packer

.. _pkg.android_google_apis_packer:

android_google_apis_packer
==========================

-  `Official <https://github.com/hunter-packages/android_google_apis_packer>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/android_google_apis_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_google_apis_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
