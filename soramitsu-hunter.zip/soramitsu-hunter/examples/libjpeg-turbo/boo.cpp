#include <cstdio>
#include <jpeglib.h>

int main(int argc, char **argv)
{
  jpeg_error_mgr jerr;
  jpeg_std_error(&jerr);
}
