.. spelling::

    tiny-process-library

.. index::
  single: unsorted ; tiny-process-library

.. _pkg.tiny-process-library:

tiny-process-library
====================

-  `Official <https://gitlab.com/eidheim/tiny-process-library>`__
-  `Hunterized <https://github.com/cpp-pm/tiny-process-library>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/tiny-process-library/CMakeLists.txt>`__
-  Added by `Joerg-Christian Boehme <https://github.com/Bjoe>`__ (`pr-102 <https://github.com/cpp-pm/hunter/pull/102>`__)

.. literalinclude:: /../examples/tiny-process-library/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
