#include <webp/decode.h>
#include <webp/encode.h>
#include <webp/types.h>

int main() {
    return 0;
}

