#include <opentracing/tracer.h>

int main()
{
    return 0;
}
