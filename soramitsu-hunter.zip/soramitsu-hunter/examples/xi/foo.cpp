#include <X11/extensions/XInput2.h>

int main() {
}
