#include <phys/units/quantity.hpp>

int main() {
}
