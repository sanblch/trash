#include <rosgraph_msgs/Log.h>

int main() {
}
