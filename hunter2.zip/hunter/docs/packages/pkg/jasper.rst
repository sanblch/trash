.. spelling::

    jasper

.. index:: unsorted ; jasper

.. _pkg.jasper:

jasper
======

- http://www.ece.uvic.ca/~frodo/jasper/
- `Official GitHub <https://github.com/mdadams/jasper>`__
- `Hunterized <https://github.com/hunter-packages/jasper>`__
- `Example <https://github.com/cpp-pm/hunter/blob/master/examples/jasper/CMakeLists.txt>`__

.. literalinclude:: /../examples/jasper/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
