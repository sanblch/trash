.. spelling::

    sentry

.. index::
  single: unsorted ; sentry

.. _pkg.sentry:

sentry
========

-  `Official <https://github.com/getsentry/sentry-native>`__
-  `Hunterized <https://github.com/cpp-pm/sentry-native>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/sentry/CMakeLists.txt>`__

.. literalinclude:: /../examples/sentry/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
