.. spelling::

    rabit

.. index:: messaging ; rabit

.. _pkg.rabit:

rabit
=====

-  `Official <https://github.com/dmlc/rabit>`__
-  `Hunterized <https://github.com/hunter-packages/rabit/tree/hunter>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/rabit/CMakeLists.txt>`__

.. literalinclude:: /../examples/rabit/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
