#include <GL/glu.h>

int main() {
}
