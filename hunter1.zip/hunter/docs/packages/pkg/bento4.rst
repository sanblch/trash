.. spelling::

    bento

.. index:: media ; bento4

.. _pkg.bento4:

bento4
======

-  `Official <https://github.com/axiomatic-systems/Bento4>`__
-  `Hunterized <https://github.com/cpp-pm/Bento4>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/bento4/CMakeLists.txt>`__
-  Added by `Brad Kotsopoulos <https://github.com/bkotzz>`__ (`pr-1797 <https://github.com/ruslo/hunter/pull/1797>`__)

.. literalinclude:: /../examples/bento4/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
