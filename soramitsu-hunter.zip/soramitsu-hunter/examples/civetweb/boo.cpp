#include <civetweb.h>

int main() {
  unsigned features = 0;
  return mg_init_library(features);
}
