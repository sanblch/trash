/**
 * Copyright Soramitsu Co., Ltd. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

namespace soralog {

  const char *__library_name;  // NOLINT

}  // namespace soralog
