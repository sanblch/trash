#include <mojoshader/mojoshader.h>

int main() {
  return MOJOSHADER_version();
}
