.. spelling::

    xatlas

.. index::
  single: unsorted ; xatlas

.. _pkg.xatlas:

xatlas
======

-  `Official <https://github.com/jpcy/xatlas>`__
-  `Hunterized <https://github.com/cpp-pm/xatlas>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/xatlas/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-233 <https://github.com/cpp-pm/hunter/pull/233>`__)

.. literalinclude:: /../examples/xatlas/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
