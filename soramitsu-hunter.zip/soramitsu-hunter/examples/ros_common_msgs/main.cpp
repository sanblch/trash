#include <sensor_msgs/Joy.h>
#include <sensor_msgs/image_encodings.h>

int main() {
}
