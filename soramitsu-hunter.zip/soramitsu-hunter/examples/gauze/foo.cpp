#include <cstdlib>

int gauze_main(int argc, char** argv) {
  return EXIT_SUCCESS;
}
