#include <google_breakpad/common/breakpad_types.h>

int main() {
}
