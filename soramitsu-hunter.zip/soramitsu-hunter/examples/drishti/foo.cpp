#include <drishti/EyeSegmenter.hpp>

int main() {
  std::string sModel;
  drishti::sdk::EyeSegmenter segmenter(sModel);
}
