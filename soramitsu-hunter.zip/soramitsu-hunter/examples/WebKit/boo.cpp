#include <JavaScriptCore/JSBase.h>

int main() {
}
