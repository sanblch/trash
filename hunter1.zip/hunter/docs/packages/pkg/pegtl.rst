.. spelling::

    pegtl

.. index::
  single: unsorted ; pegtl

.. _pkg.pegtl:

pegtl
=====

-  `Official <https://github.com/taocpp/PEGTL>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/pegtl/CMakeLists.txt>`__
-  Added by `Jörg-Christian Böhme <https://github.com/Bjoe>`__ (`pr-1905 <https://github.com/ruslo/hunter/pull/1905>`__)

.. literalinclude:: /../examples/pegtl/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
