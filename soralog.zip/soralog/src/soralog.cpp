/**
 * Copyright Soramitsu Co., Ltd. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

namespace soralog {

  // to suppress warning about no symbols in cpp
  const char *__library_name = "soralog";

}  // namespace soralog
