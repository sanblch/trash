#include <spirv-tools/libspirv.hpp>

int main() {
}
