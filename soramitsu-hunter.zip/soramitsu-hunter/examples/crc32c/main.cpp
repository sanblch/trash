#include <crc32c/crc32c.h>

int main()
{
    return 0;
}
