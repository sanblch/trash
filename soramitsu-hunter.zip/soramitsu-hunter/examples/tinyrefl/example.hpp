namespace example
{

struct A
{
    int a = 42;
};

}