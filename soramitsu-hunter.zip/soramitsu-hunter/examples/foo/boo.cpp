#include <foo/foo.hpp>

int main() {
}
