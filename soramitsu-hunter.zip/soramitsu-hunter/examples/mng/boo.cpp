#include <libmng.h>

int main() {
}
