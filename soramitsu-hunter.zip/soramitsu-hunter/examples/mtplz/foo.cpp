#include <decode/system.hh>

int main() {
}
