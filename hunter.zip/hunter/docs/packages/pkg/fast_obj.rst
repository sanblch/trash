.. spelling::

    fast_obj

.. index::
  single: graphics ; fast_obj

.. _pkg.fast_obj:

fast_obj
========

-  `Official <https://github.com/thisistherk/fast_obj>`__
-  `Hunterized <https://github.com/cpp-pm/fast_obj>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/fast_obj/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-274 <https://github.com/cpp-pm/hunter/pull/274>`__)

.. literalinclude:: /../examples/fast_obj/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
