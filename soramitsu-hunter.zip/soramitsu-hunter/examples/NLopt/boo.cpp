#include <nlopt.hpp>

int main() {
}
