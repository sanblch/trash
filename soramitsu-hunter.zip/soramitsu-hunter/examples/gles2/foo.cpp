// Copyright (c) 2017, Ruslan Baratov
// All rights reserved.

#include <GLES2/gl2.h>

int main() {
}
