print('Hello Hunter! (script)')
