#include <angles/angles.h>

int main() {
}
