#include <vulkan/vulkan.h>

// Vertex buffer and attributes
struct {
    VkDeviceMemory memory;
    VkBuffer buffer;
} vertices;

int main() {
}
