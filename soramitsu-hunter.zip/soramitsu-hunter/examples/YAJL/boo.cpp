#include <yajl/yajl_common.h>

int main() {
}
