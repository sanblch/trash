#include <acf/ACF.h>

int main() {
    acf::Detector("just_a_test");
}
