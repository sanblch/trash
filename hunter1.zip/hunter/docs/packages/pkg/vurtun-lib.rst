.. spelling::

    vurtun

.. index::
  single: unsorted ; vurtun-lib

.. _pkg.vurtun-lib:

vurtun-lib
==========

-  `Official <https://github.com/vurtun/lib>`__
-  `Hunterized <https://github.com/cpp-pm/vurtun-lib>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/vurtun-lib/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-431 <https://github.com/cpp-pm/hunter/pull/431>`__)

.. literalinclude:: /../examples/vurtun-lib/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
