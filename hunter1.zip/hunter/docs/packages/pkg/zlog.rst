.. spelling::

    zlog

.. index:: Logging ; zlog

.. _pkg.zlog:

zlog
====

-  `Official <https://hardysimpson.github.io/zlog>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/zlog/CMakeLists.txt>`__
-  Added by `je-vv <https://github.com/je-vv>`__ (`pr-N <https://github.com/cpp-pm/hunter/pull/N>`__)

.. literalinclude:: /../examples/zlog/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
