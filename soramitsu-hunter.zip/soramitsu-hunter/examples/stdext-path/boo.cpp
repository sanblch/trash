#include <stdext/path.h>

int main() {
}
