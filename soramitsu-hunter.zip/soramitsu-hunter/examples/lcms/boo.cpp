#include <lcms2.h>

int main() {
}
