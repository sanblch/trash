.. spelling::

    taocpp
    json

.. index::
  single: unsorted ; taocpp-json

.. _pkg.taocpp-json:

taocpp-json
===========

-  `Official <https://github.com/taocpp/json>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/taocpp-json/CMakeLists.txt>`__
-  Added by `Jörg-Christian Böhme <https://github.com/BJoe>`__ (`pr-1906 <https://github.com/ruslo/hunter/pull/1906>`__)

.. literalinclude:: /../examples/taocpp-json/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
