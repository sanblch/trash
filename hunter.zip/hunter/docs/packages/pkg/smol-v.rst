.. spelling::

    smol
    v

.. index::
  single: graphics ; smol-v

.. _pkg.smol-v:

smol-v
======

-  `Official <https://github.com/aras-p/smol-v>`__
-  `Hunterized <https://github.com/cpp-pm/smol-v>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/smol-v/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-281 <https://github.com/cpp-pm/hunter/pull/281>`__)

.. literalinclude:: /../examples/smol-v/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
