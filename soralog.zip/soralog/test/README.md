# test

To add test, use:

```
# define binary
addtest(example1 part1.cpp)
# attach more sources
addtest_part(example1 part2.cpp)
```

OR

```
# define all sources in one test
addtest(example2 part1.cpp part2.cpp)
```
