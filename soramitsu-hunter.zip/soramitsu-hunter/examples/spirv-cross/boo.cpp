#include "spirv_cross.hpp"

int main() {
}
