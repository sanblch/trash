// Copyright (c) 2017, Ruslan Baratov
// All rights reserved.

#include <android/api-level.h>

int main() {
}
