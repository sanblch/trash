#include <network/uri/uri.hpp>

int main() {
    network::uri uri;
    return uri.string().length();
}
