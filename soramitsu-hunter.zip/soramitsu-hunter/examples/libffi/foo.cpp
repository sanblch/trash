#include <ffi.h>

int main() {
}
