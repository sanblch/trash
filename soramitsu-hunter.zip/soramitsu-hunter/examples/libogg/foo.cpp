// #include <ogg/ogg.h> (FIXME)

int main() {
}
