#import <CoreAudio/CoreAudio.h>

int main() {
}
