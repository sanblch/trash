#include <X11/X.h>

int main() {
}
