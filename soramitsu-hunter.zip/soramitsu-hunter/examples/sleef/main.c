#include <stdio.h>
#include <sleef.h>

int main() {
    double lu35 = Sleef_log_u35(35.0);

    return 0;
}
