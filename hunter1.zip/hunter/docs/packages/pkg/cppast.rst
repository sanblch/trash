.. spelling::

    cppast

.. index::
  single: unsorted ; cppast

.. _pkg.cppast:

cppast
======

-  `Official <https://github.com/foonathan/cppast>`__
-  `Hunterized <https://github.com/cpp-pm/cppast>`
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/cppast/CMakeLists.txt>`__
-  Added by `Joerg-Christian Boehme <https://github.com/Bjoe>`__ (`pr-110 <https://github.com/cpp-pm/hunter/pull/110>`__)

.. literalinclude:: /../examples/cppast/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
