#include <farmhash.h>

int main() {
}
