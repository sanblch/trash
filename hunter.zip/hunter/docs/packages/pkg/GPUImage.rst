.. spelling::

    GPUImage

.. index:: concurrency ; GPUImage

.. _pkg.GPUImage:

GPUImage
========

-  `Official <https://github.com/BradLarson/GPUImage>`__
-  `Hunterized <https://github.com/hunter-packages/GPUImage>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/GPUImage/CMakeLists.txt>`__

.. literalinclude:: /../examples/GPUImage/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
