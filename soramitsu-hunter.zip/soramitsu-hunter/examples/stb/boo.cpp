#include <stb/stb_image.h>
#include <stb/stb_image_write.h>
#include <stb/stb_rect_pack.h>
#include <stb/stb_vorbis.h>

int main() {
}
