.. spelling::

    EnumGroup

.. index:: unsorted ; EnumGroup

.. _pkg.EnumGroup:

EnumGroup
=========

-  `Official <https://github.com/Person-93/EnumGroup>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/EnumGroup/CMakeLists.txt>`__
-  Added by `EnumGroup_developer <https://github.com/Person-93>`__ (`pr-1368 <https://github.com/ruslo/hunter/pull/1368>`__)

.. literalinclude:: /../examples/EnumGroup/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
