#include <dlpack/dlpack.h>

int main() {
}
