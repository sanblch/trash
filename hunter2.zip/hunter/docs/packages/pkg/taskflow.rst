.. spelling::

    taskflow

.. index::
  single: concurrency ; taskflow

.. _pkg.taskflow:

taskflow
========

-  `Official <https://taskflow.github.io/>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/taskflow/CMakeLists.txt>`__
-  Added by `Raffael Casagrande <https://github.com/craffael>`__ (`pr-371 <https://github.com/cpp-pm/hunter/pull/371>`__)

.. literalinclude:: /../examples/taskflow/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
