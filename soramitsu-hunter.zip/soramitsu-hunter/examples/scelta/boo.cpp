#include <scelta.hpp>
#include <scelta/match.hpp>

int main() {
    scelta::match();
}
