#include <glslang/Public/ShaderLang.h>

int main() {
}
