.. spelling::

    nose

.. index::
  single: python ; pip_nose-timer

.. _pkg.pip_nose-timer:

pip_nose-timer
==============

- `Official GitHub <https://github.com/mahmoudimus/nose-timer>`__
- `PyPI <https://pypi.org/project/nose-timer>`__
- `Example <https://github.com/cpp-pm/hunter/blob/master/examples/pip_nose-timer/CMakeLists.txt>`__

.. literalinclude:: /../examples/pip_nose-timer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
