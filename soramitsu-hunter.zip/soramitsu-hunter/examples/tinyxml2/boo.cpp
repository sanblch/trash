#include <tinyxml2.h>

int main() {
    tinyxml2::XMLDocument doc;
    doc.LoadFile("dummy.xml");

    return 0;
}
