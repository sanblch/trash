.. spelling::

    nng

.. index::
  single: unsorted ; nng

.. _pkg.nng:

nng
===

-  `Official <https://nanomsg.github.io/nng/index.html>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/nng/CMakeLists.txt>`__
-  Added by `tnixeu <https://github.com/tnixeu>`__ (`pr-45 <https://github.com/cpp-pm/hunter/pull/45>`__)

.. literalinclude:: /../examples/nng/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
