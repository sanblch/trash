#include <GPUImage/GPUImageGrayscaleFilter.h>

int main() {
    auto *filter = [[GPUImageGrayscaleFilter alloc] init];
}
